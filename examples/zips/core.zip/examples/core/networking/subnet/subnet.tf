// Copyright (c) 2017, 2024, Oracle and/or its affiliates. All rights reserved.
// Licensed under the Mozilla Public License v2.0

variable "tenancy_ocid" {
}

variable "compartment_ocid" {
}

variable "region" {
}

provider "oci" {
  config_file_profile = "terraform-federation-test"
  auth = "SecurityToken"
}

data "oci_identity_availability_domain" "ad" {
  compartment_id = var.tenancy_ocid
  ad_number      = 1
}

resource "oci_core_vcn" "vcn1" {
  cidr_block     = "10.0.0.0/16"
  compartment_id = var.compartment_ocid
  display_name   = "exampleVCN"
  dns_label      = "tfexamplevcn"
}

// A regional subnet will not specify an Availability Domain
resource "oci_core_subnet" "regional_subnet" {
  cidr_block        = "10.0.1.0/24"
  display_name      = "regionalSubnet"
  dns_label         = "regionalsubnet"
  compartment_id    = var.compartment_ocid
  vcn_id            = oci_core_vcn.vcn1.id
  security_list_ids = [oci_core_vcn.vcn1.default_security_list_id]
  route_table_id    = oci_core_vcn.vcn1.default_route_table_id
  dhcp_options_id   = oci_core_vcn.vcn1.default_dhcp_options_id
}

// An AD based subnet will supply an Availability Domain
resource "oci_core_subnet" "ad_subnet" {
  availability_domain = data.oci_identity_availability_domain.ad.name
  cidr_block          = "10.0.2.0/24"
  display_name        = "ADSubnet"
  dns_label           = "adsubnet"
  compartment_id      = var.compartment_ocid
  vcn_id              = oci_core_vcn.vcn1.id
  security_list_ids   = [oci_core_vcn.vcn1.default_security_list_id]
  route_table_id      = oci_core_vcn.vcn1.default_route_table_id
  dhcp_options_id     = oci_core_vcn.vcn1.default_dhcp_options_id
}

// A subnet with multiple Ipv4 cidr blocks
resource "oci_core_subnet" "multiple_cidr_subnet" {
  ipv4cidr_blocks   = ["10.0.3.0/24", "10.0.4.0/24"]
  display_name      = "multipleCidrSubnet"
  dns_label         = "multiplecidr"
  compartment_id    = var.compartment_ocid
  vcn_id            = oci_core_vcn.vcn1.id
  security_list_ids = [oci_core_vcn.vcn1.default_security_list_id]
  route_table_id    = oci_core_vcn.vcn1.default_route_table_id
  dhcp_options_id   = oci_core_vcn.vcn1.default_dhcp_options_id
}

# List Private IPs
data "oci_core_subnets" "subnet_datasource" {
  vcn_id = oci_core_subnet.regional_subnet.vcn_id
  compartment_id = oci_core_subnet.regional_subnet.compartment_id
}

output "subnets" {
  value = [data.oci_core_subnets.subnet_datasource.subnets]
}

